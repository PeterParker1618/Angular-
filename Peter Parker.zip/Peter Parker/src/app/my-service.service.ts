import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import{Employee} from './Employee';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  employees:Employee[]=[];

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchEmployees();
  }

  fetched:boolean=false;

  fetchEmployees()
  {
    this.http.get('./assets/Employee.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  getEmployees():Employee[]
  {
    return this.employees;
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Employee(o.eid,o.ename,o.gender,o.edesignation,o.Salary,o.eaddress,o.econtact);
      this.employees.push(e);
    }
  }
  
  delete(eid:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.employees.length;i++)
    {
      let e=this.employees[i];
      if(eid==e.eid)
      {
        foundIndex=i;
        break;
      }
    }
    this.employees.splice(foundIndex,1);
  }

  add(e:Employee){
    this.employees.push(e);
  }

  update(data:Employee)
  {
    let eid=data.eid;
    for(let i=0;i<this.employees.length;i++)
    {
      if(eid === this.employees[i].eid)
      {
        this.employees[i].eid=data.eid;
        this.employees[i].ename=data.ename;
        this.employees[i].gender=data.gender;
        this.employees[i].edesignation=data.edesignation;
        this.employees[i].Salary=data.Salary;
        this.employees[i].eaddress=data.eaddress;
        this.employees[i].econtact=data.econtact;
        break;
      }
    }
  }
  
  Studentse:Employee[];
  searchData(data):Employee[] {
  this.Studentse=[];
  for(let e of this.employees) {
  if(e.eid==data.id) {
  this.Studentse.push(e);
   }
   }
  return this.Studentse;
   }
}
